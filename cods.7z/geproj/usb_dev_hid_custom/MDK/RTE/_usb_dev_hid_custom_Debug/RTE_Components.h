
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'usb_dev_hid_custom' 
 * Target:  'usb_dev_hid_custom_Debug' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "HC32F460JCTA.h"


#endif /* RTE_COMPONENTS_H */
